MY LAGOS Android Project v0.6

This is an Android Studio Gradle project wrapping the MY LAGOS browser prototype in a WebView.
Build with JDK 17 and Gradle 8.9 (Android Gradle Plugin 8.7.3).
The 3D engine is loaded from jsDelivr, so the phone needs internet access when the game opens.

v0.6 updates:
- Fixed car placement coordinates (cars were placed vertically instead of across the ground).
- Reversed on-foot movement sign to align forward/backward with the camera view.
- Added a basic furnished house interior; tap ENTER / EXIT near a house to enter and again to leave.
- Save data key updated to mylagos06 so it doesn't overwrite v0.5 saves.

This is a prototype, not a finished commercial game. Test on device before adding more features.
